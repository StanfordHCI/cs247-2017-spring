/**
 * --------------------------------------------------------------------
 * jQuery collapsible plugin
 * Author: Scott Jehl, scott@filamentgroup.com
 * Copyright (c) 2009 Filament Group 
 * licensed under MIT (filamentgroup.com/examples/mit-license.txt)
 * --------------------------------------------------------------------
 */
$.fn.collapsible = function()
{
	 return $(this).each(function()
	 {
	
		//define
		var collapsibleHeading = $(this);
		var collapsibleContent = collapsibleHeading.parent().next();;
		
		
		
		collapsibleHeading.css('display','inline-block');				
		collapsibleHeading.addClass('collapsible-h-toggle');
				
		collapsibleContent.addClass('collapsible-content');
		
		//events
		collapsibleHeading	
		
			.bind('collapse', function(){
				$(this).removeClass('collapsible-h-toggle');
				$(this).addClass('collapsible-h-collapsed');
										
				collapsibleContent.slideUp(function(){
					$(this).addClass('collapsible-content-collapsed').removeAttr('style').attr('aria-hidden',true);
				});
			})
			.bind('expand', function(){
				$(this).removeClass('collapsible-h-collapsed');
				$(this).addClass('collapsible-h-toggle');
										
				collapsibleContent.slideDown(function(){
					 $(this).removeClass('collapsible-content-collapsed').removeAttr('style').attr('aria-hidden',false);
				});
			})
		    .bind('collapseALL', function(){		     
		       		        
			   $(this).parent().parent().find('.exp_col').each(function (){ 		        
			        $(this).trigger('collapse');
			        });
			})		
			.click(function(){ 			
				if( $(this).is('.collapsible-h-collapsed') ){
				
					//$(this).trigger('collapseALL'); 
					
					$(this).trigger('expand'); 					
				}					
				else {
					$(this).trigger('collapse'); 
				}
				return false;
			})		    
			
			//.trigger('collapse');
			
			
			
	    });	 //return $(this).each(function()
	
};	//$.fn.collapsible = function()
